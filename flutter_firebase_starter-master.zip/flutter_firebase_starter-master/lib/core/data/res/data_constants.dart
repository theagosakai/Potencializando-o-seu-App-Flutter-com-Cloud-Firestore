class AppDBConstants {
  static const String usersCollection = "users";
  static const String appSettingsCollection = "app_settings";
  static const String usersStorageBucket = "users";

  static const String devicesSubCollection = "devices";
}