class AppAssets {

}