class AppConstants {
  static const String appName="Firebase starter";
  static const String appNameDev="[DEV] Firebase starter";

}