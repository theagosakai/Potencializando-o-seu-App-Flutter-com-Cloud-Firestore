class AppSizes {
  static const double borderRadius=10.0;
}