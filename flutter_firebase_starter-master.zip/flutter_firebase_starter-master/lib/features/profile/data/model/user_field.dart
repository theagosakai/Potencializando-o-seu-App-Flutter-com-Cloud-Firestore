class UserFields {
  static const String id = "id";
  static const String name = "name";
  static const String email =  "email";
  static const String lastLoggedIn = "last_logged_in";
  static const String registrationDate = "registration_date";
  static const String photoUrl="photo_url";
  static const String buildNumber="build_number";
  static const lastUpdated = "last_updated_date";
  static const String introSeen = "intro_seen";
}